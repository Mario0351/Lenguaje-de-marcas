var clima = require('./current_clima.json');

var hours = clima.forecast.forecastday.hour;

hours.forEach(function(item) {

})