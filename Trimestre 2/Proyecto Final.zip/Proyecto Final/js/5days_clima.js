var clima = require('./5days_clima.json');

var days = clima.forecast.forecastday;

days.forEach(function(item) {

})